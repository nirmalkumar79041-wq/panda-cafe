const BASE = import.meta.env.VITE_API_URL || 'http://localhost:8080';
export async function request(path, options={}) {
  const response = await fetch(`${BASE}/api${path}`, {
    ...options, headers: {'Content-Type':'application/json', ...(options.headers||{})}
  });
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try { const body = await response.json(); message = body.detail || body.message || message; } catch {}
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}
