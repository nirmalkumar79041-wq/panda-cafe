import React, {useEffect, useMemo, useState} from 'react';
import {request} from '../api';

export default function Customer(){
  const [items,setItems]=useState([]), [error,setError]=useState(''), [search,setSearch]=useState(''), [category,setCategory]=useState('All');
  async function load(){try{setItems(await request('/menu'));setError('')}catch(e){setError('Menu is temporarily unavailable. Please try again.');}}
  useEffect(()=>{load();const timer=setInterval(load,3000);return()=>clearInterval(timer)},[]);
  const categories=useMemo(()=>['All',...new Set(items.map(i=>i.category))],[items]);
  const visible=items.filter(i=>(category==='All'||i.category===category)&&i.name.toLowerCase().includes(search.toLowerCase()));
  return <main className="shell">
    <header className="hero"><div className="brandmark">🐼</div><div><p className="eyebrow">WELCOME TO</p><h1>PANDA <span>CAFE</span></h1><p className="tagline">Unlimited Happiness</p></div></header>
    <div className="intro"><div><p className="eyebrow">OUR MENU</p><h2>Good food. Good mood.</h2></div><span className="live"><i/> Live availability</span></div>
    <input className="search" placeholder="Search your favourite food..." value={search} onChange={e=>setSearch(e.target.value)}/>
    <nav className="chips">{categories.map(c=><button key={c} className={category===c?'chip active':'chip'} onClick={()=>setCategory(c)}>{c}</button>)}</nav>
    {error&&<p className="error">{error}</p>}
    <section className="menu-grid">{visible.map(item=><article className={`food-card ${!item.available?'sold':''}`} key={item.id}>
      <div className="food-top"><span className="food-icon">{iconFor(item.category)}</span><span className={item.available?'status':'status off'}>{item.available?'Available':'Sold out'}</span></div>
      <h3>{item.name}</h3><div className="price">{item.price}</div>
      {!item.available&&<div className="sold-overlay">Currently unavailable</div>}
    </article>)}</section>
    {!visible.length&&!error&&<p className="empty">No menu items found.</p>}
    <footer>© Panda Cafe · Made with ❤️</footer>
  </main>
}
function iconFor(c){return ({Burgers:'🍔','Bread Omelette':'🍳','Fries & Snacks':'🍟','Fried Chicken':'🍗',Momos:'🥟',Maggi:'🍜','Fresh Juice':'🧃','Ice Cream':'🍨',Waffles:'🧇',Mojito:'🍹',Milkshakes:'🥤',Refreshments:'☕',Sandwich:'🥪',Pizza:'🍕'})[c]||'🍽️'}
