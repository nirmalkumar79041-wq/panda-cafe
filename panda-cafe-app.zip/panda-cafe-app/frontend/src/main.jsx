import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Customer from './pages/Customer.jsx';
import Admin from './pages/Admin.jsx';
import './style.css';
function App(){return <BrowserRouter><Routes><Route path="/" element={<Customer/>}/><Route path="/admin" element={<Admin/>}/></Routes></BrowserRouter>}
createRoot(document.getElementById('root')).render(<App/>);
