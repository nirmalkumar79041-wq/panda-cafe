# Panda Cafe – Customer + Admin Web Apps

A starter full-stack project with:
- Customer menu at `/`
- Restaurant admin at `/admin`
- React + Vite frontend
- Spring Boot REST API
- MySQL database
- Automatic customer menu refresh every 3 seconds (near-real-time)

## Requirements
- Java 17+
- Maven 3.9+
- Node.js 20+
- Docker Desktop (recommended for MySQL)

## 1. Start MySQL
From the project root:
```bash
docker compose up -d
```

## 2. Start the backend
```bash
cd backend
mvn spring-boot:run
```
Backend: http://localhost:8080

Default admin password: `change-this-password`
Change it in `backend/src/main/resources/application.properties` before deployment.

## 3. Start the frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

Admin page: http://localhost:5173/admin

## Admin security
The admin screen asks for the password. The backend compares it with `ADMIN_PASSWORD`.
For a real public launch, replace this simple shared-password starter with proper individual accounts,
HTTPS, rate limiting, backups, and stronger authentication.

## Deploying for use on different phones
Localhost works only on your own computer. To let customers and staff access it from anywhere:
1. Deploy the Spring Boot backend and MySQL database to a hosting provider.
2. Set `VITE_API_URL` in the frontend hosting environment to your backend URL.
3. Deploy the frontend.
4. Use the deployed customer URL in a QR code.

Free hosting availability and sleep/usage limits vary by provider. This project itself does not require Firebase
or paid third-party APIs. Hosting and database providers may have their own limits or charges.

## Menu data
The initial menu is seeded from the uploaded Panda Cafe menu PDF. Where the PDF showed two unlabeled prices,
both are shown as two prices separated by `/`; confirm what those two columns mean before launch.
Items visibly crossed out or blacked out in the PDF are not included.
