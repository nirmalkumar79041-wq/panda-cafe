package com.pandacafe;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MenuSeeder implements CommandLineRunner {
    private final MenuRepository repo;
    public MenuSeeder(MenuRepository repo) { this.repo = repo; }

    @Override public void run(String... args) {
        if (repo.count() > 0) return;
        int n = 1;
        n = add("Burgers", n,
            new String[][]{{"Veg Burger / with Cheese","₹70 / ₹85"},{"Chicken Burger / with Cheese","₹80 / ₹95"},
            {"Paneer Burger / with Cheese","₹100 / ₹115"},{"Double Chicken Burger / with Cheese","₹145 / ₹160"}});
        n = add("Bread Omelette", n, new String[][]{{"Mayo Bread Omelette","₹50"},{"Cheese Bread Omelette","₹60"},{"Chicken Bread Omelette","₹70"},{"Paneer Bread Omelette","₹70"}});
        n = add("Fries & Snacks", n, new String[][]{{"Masala French Fries","₹50"},{"French Fries + Mayo","₹40 + ₹10"},{"Veg Samosa (3 pcs)","₹40"},{"Veg Fingers (3 pcs)","₹45"},{"Veg Nuggets (4 pcs)","₹50"},{"Smiley (5 nos)","₹55"},{"Veg Roll","₹60"},{"Chicken Nuggets (4 pcs)","₹50"},{"Chicken Fingers (3 pcs)","₹50"},{"Chicken Samosa (4 pcs)","₹55"},{"Chicken Cheese Ball (6 pcs)","₹70"},{"Chicken Bites (8 pcs)","₹80"},{"Chicken Roll","₹80"}});
        n = add("Fried Chicken", n, new String[][]{{"Chicken Wings (3 pcs)","₹120"},{"Chicken Lollipop (4 pcs)","₹150"},{"Chicken Tender (4 pcs)","₹100"}});
        n = add("Momos", n, new String[][]{{"Veg Momos (5 pcs) – Fried / Steamed","₹60 / ₹70"},{"Veg Paneer Tika Momo (5 pcs) – Fried / Steamed","₹70 / ₹80"},{"Corn Cheese Momos (5 pcs) – Fried / Steamed","₹75 / ₹85"},{"Chicken Momo (5 pcs) – Fried / Steamed","₹70 / ₹80"},{"Chicken Peri Peri Momo (5 pcs) – Fried / Steamed","₹75 / ₹85"}});
        n = add("Maggi", n, new String[][]{{"Plain Maggi","₹45"},{"Veg Maggi","₹50"},{"Egg Maggi","₹60"},{"Corn Maggi","₹60"},{"Cheese Maggi","₹65"},{"Chicken Maggi","₹75"},{"Paneer Maggi","₹70"}});
        n = add("Fresh Juice", n, new String[][]{{"Pomegranate","₹70"},{"Apple","₹60"},{"Red Banana","₹50"},{"Lemon Juice","₹30"},{"Lemon Soda","₹40"},{"Orange","₹70"},{"Watermelon","₹40"},{"Fig","₹40"},{"Mosambi (Sweet Lemon)","₹60"},{"Butterfruit","₹90"},{"Muskmelon","₹50"}});
        n = add("Ice Cream", n, new String[][]{{"Vanilla Scoop / Cone","₹55 / ₹25"},{"Strawberry Scoop / Cone","₹55 / ₹25"},{"Chocolate Scoop / Cone","₹65 / ₹30"},{"Pista Scoop / Cone","₹55 / ₹30"},{"Mango Scoop / Cone","₹55 / ₹30"},{"Butterscotch Scoop / Cone","₹65 / ₹30"},{"Blackcurrant Scoop / Cone","₹75 / ₹30"}});
        n = add("Waffles", n, new String[][]{{"Honey Waffle","₹90"},{"Caramel Waffle","₹100"},{"Chocolate Waffle","₹110"},{"White Chocolate Waffle","₹130"},{"Oreo Waffle","₹140"}});
        n = add("Mojito", n, new String[][]{{"Lemon Mint Mojito","₹70"},{"Blue Ocean Mojito","₹80"},{"Litchi Mojito","₹80"},{"Pista Mojito","₹80"}});
        n = add("Milkshakes", n, new String[][]{{"Rose Milkshake","₹40"},{"Strawberry Shake","₹50"},{"Cold Boost Shake","₹50"},{"Butterscotch Shake","₹60"},{"Black Currant Shake","₹60"},{"Badam Milkshake","₹60"},{"Chocolate Shake","₹60"},{"Oreo Shake","₹70"},{"Kit Kat Shake","₹70"}});
        n = add("Refreshments", n, new String[][]{{"Tea","₹15"},{"Coffee","₹20"},{"Green Tea","₹15"},{"Lemon Tea","₹15"},{"Lemon Honey Tea","₹20"},{"Ginger Tea","₹20"},{"Black Tea","₹15"},{"Black Coffee","₹15"},{"Badam Milk","₹25"},{"Boost Milk","₹25"},{"Horlicks","₹25"},{"Extra Brown Sugar","₹5"}});
        n = add("Sandwich", n, new String[][]{{"Veg Sandwich","₹50"},{"Sweetcorn Sandwich","₹60"},{"Cheese Sandwich","₹70"},{"Paneer Sandwich","₹65"},{"Chocolate Sandwich","₹70"},{"Egg Sandwich","₹60"},{"Chicken Sandwich","₹70"}});
        add("Pizza", n, new String[][]{{"Margherita Pizza","₹100"},{"Veg Cheese Pizza","₹120"},{"Corn Cheese Pizza","₹120"},{"Paneer Pizza","₹130"},{"Chicken Pizza","₹140"}});
    }

    private int add(String category, int order, String[][] items) {
        for (String[] row : items) repo.save(new MenuItem(category, row[0], "", row[1], order++));
        return order;
    }
}
