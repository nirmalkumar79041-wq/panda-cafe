package com.pandacafe;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class MenuController {
    private final MenuRepository repo;
    @Value("${app.admin-password}") private String adminPassword;

    public MenuController(MenuRepository repo) { this.repo = repo; }

    @GetMapping("/menu")
    public List<MenuItem> menu() { return repo.findAllByOrderBySortOrderAscIdAsc(); }

    @PostMapping("/admin/login")
    public Map<String, Boolean> login(@RequestBody Map<String, String> body) {
        if (!adminPassword.equals(body.get("password"))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Incorrect password");
        }
        return Map.of("ok", true);
    }

    @PatchMapping("/admin/menu/{id}/availability")
    public MenuItem availability(@PathVariable Long id, @RequestHeader("X-Admin-Password") String password,
                                 @RequestBody Map<String, Boolean> body) {
        checkAdmin(password);
        MenuItem item = repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        item.available = Boolean.TRUE.equals(body.get("available"));
        return repo.save(item);
    }

    @PostMapping("/admin/menu")
    public MenuItem add(@RequestHeader("X-Admin-Password") String password, @RequestBody MenuItem item) {
        checkAdmin(password);
        item.id = null;
        return repo.save(item);
    }

    @PutMapping("/admin/menu/{id}")
    public MenuItem edit(@PathVariable Long id, @RequestHeader("X-Admin-Password") String password,
                         @RequestBody MenuItem update) {
        checkAdmin(password);
        MenuItem item = repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        item.category = update.category; item.name = update.name;
        item.description = update.description; item.price = update.price;
        item.sortOrder = update.sortOrder;
        return repo.save(item);
    }

    @DeleteMapping("/admin/menu/{id}")
    public void delete(@PathVariable Long id, @RequestHeader("X-Admin-Password") String password) {
        checkAdmin(password);
        repo.deleteById(id);
    }

    private void checkAdmin(String password) {
        if (!adminPassword.equals(password)) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Admin login required");
    }
}
