package com.pandacafe;

import jakarta.persistence.*;

@Entity
public class MenuItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String category;
    public String name;
    public String description;
    public String price;
    public boolean available = true;
    public int sortOrder;

    public MenuItem() {}
    public MenuItem(String category, String name, String description, String price, int sortOrder) {
        this.category = category; this.name = name; this.description = description;
        this.price = price; this.sortOrder = sortOrder; this.available = true;
    }
}
