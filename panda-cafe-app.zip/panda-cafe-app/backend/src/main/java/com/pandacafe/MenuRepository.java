package com.pandacafe;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuRepository extends JpaRepository<MenuItem, Long> {
    List<MenuItem> findAllByOrderBySortOrderAscIdAsc();
}
