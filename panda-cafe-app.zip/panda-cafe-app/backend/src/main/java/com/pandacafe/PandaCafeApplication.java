package com.pandacafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PandaCafeApplication {
    public static void main(String[] args) {
        SpringApplication.run(PandaCafeApplication.class, args);
    }
}
